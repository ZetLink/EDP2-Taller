package excepciones;

public class AlturaException extends Exception {
    public AlturaException(String message) {
        super(message);
    }
}