package excepciones;

public class AlturaNegativaException extends AlturaException {
    public AlturaNegativaException() {
        super("Altura negativa");
    }
}
